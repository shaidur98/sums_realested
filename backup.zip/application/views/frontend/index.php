
	<!-- Slider -->
	<section id="banner">
	<div id="demo-1" data-zs-src='["<?php echo base_url();?>assets/frontend/img/photos/img4.jpg", "<?php echo base_url();?>assets/frontend/img/photos/img5.jpg", "<?php echo base_url();?>assets/frontend/img/photos/img6.jpg"]' data-zs-overlay="dots">
		<div class="demo-inner-content">
			<h1><span><em>S</em>ums</span></h1><br/>
			<p>Sums Real eatate Company Ltd.</p>
		</div>
	</div>
	<!-- end slider --> 
	</section> 
	<!-----project-->
	<section class="projects">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="aligncenter"><h2 class="aligncenter">Our Projects</h2></div><br/>
					<div id="demo">
						<div class="container">
							<div class="row">
								<div class="col-sm-12 col-md-12 col-lg-12">
									<div id="owl-demo" class="owl-carousel">
										<div class="item">
											<div class="card small">
												<div class="card-image">
													<a href="priosums.html"><img class="img-responsive" src="<?php echo base_url();?>assets/frontend/img/priosums1.jpg" alt=""></a>   
												</div>
												<div class="card-content"> 
													<p><span class="price">$4.00 Lacs - 8.28 Lacs</span></p>
													<h4>Prio Sums Tower</h4>
													<h5>Residential Area,Rajshahi</h5>
													<a href="priosums.html" class="btn btn-details">Details</a>
													<p></p>
												</div>
											</div>	
										</div>
										<div class="item">
											<div class="card small">
												<div class="card-image">
													<a href="beutymansion.html"><img class="img-responsive" src="<?php echo base_url();?>assets/frontend/img/beautymansion2.jpg" alt=""></a>   
												</div>
												<div class="card-content"> 
													<p><span class="price">$4.00 Lacs - 8.28 Lacs</span></p>
													<h4>Beauty Mansion</h4>
													<h5>Residential Area of Mohananda</h5>
													<a href="beutymansion.html" class="btn btn-details">Details</a>
													<p></p>
												</div>
											</div>	
										</div>
										<div class="item">
											<div class="card small">
												<div class="card-image">
													<a href="amenatower.html"><img class="img-responsive" src="<?php echo base_url();?>assets/frontend/img/sums-amena3.jpg" alt=""></a>  
												</div>
												<div class="card-content"> 
													<p><span class="price">$4.00 Lacs - 8.28 Lacs</span></p>
													<h4>Sums Amena Tower</h4>
													<h5>Upashohar,Rajshahi</h5>
													<a href="amenatower.html" class="btn btn-details">Details</a>
													<p></p>
												</div>
											</div>	
										</div>
										<div class="item">
											<div class="card small">
												<div class="card-image">
													<a href="moniratower.html"><img class="img-responsive" src="<?php echo base_url();?>assets/frontend/img/sums-monira4.jpg" alt=""></a>  
												</div>
												<div class="card-content"> 
													<p><span class="price">$4.00 Lacs - 8.28 Lacs</span></p>
													<h4>Sums Monira Tower</h4>
													<h5>Residential Area,Rajshahi</h5>
													<a href="moniratower.html" class="btn btn-details">Details</a>
													<p></p>
												</div>
											</div>	
										</div>
										<div class="item">
											<div class="card small">
												<div class="card-image">
													<a href="priosums.html"><img class="img-responsive" src="<?php echo base_url();?>assets/frontend/img/priosums1.jpg" alt=""></a>   
												</div>
												<div class="card-content"> 
													<p><span class="price">$4.00 Lacs - 8.28 Lacs</span></p>
													<h4>Prio Sums Tower</h4>
													<h5>Residential Area,Rajshahi</h5>
													<a href="priosums.html" class="btn btn-details">Details</a>
													<p></p>
												</div>
											</div>	
										</div>
										<div class="item">
											<div class="card small">
												<div class="card-image">
													<a href="beutymansion.html"><img class="img-responsive" src="<?php echo base_url();?>assets/frontend/img/beautymansion2.jpg" alt=""></a>  
												</div>
												<div class="card-content"> 
													<p><span class="price">$4.00 Lacs - 8.28 Lacs</span></p>
													<h4>Beauty Mansion</h4>
													<h5>Residential Area of Mohananda</h5>
													<a href="beutymansion.html" class="btn btn-details">Details</a>
													<p></p>
												</div>
											</div>	
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<!---project--end-->
	<section class="section-padding gray-bg">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h2>Animation of Prio Sums Tower</h2>
					</div>
				</div>
			</div>
		</div>
	</section>
<!----youtube---->
	<div class="container">
		<div class="youtube">
			<div class="row">
				<div class="col-md-12">
					<div class="youtube-video">
						<div class="video-title"></div>
						<iframe width="800" height="345" src="https://www.youtube.com/embed/tgbNymZ7vqY"></iframe>
					</div>
					<div class="youtube-list">
						<div class='dvContent'>
							<div class="media">
								<a class="video-link" href="#">
								<div class="media-left">
									<img class="media-object" src="<?php echo base_url();?>assets/frontend/img/default.jpg" alt="show">
								</div>
								<div class="media-body">
									<h4 class="media-heading">Happy New Year 2017, Wishes, video download,Whatsapp </h4>
									<div class="time-text">01:51</div>
								</div>
								</a>
							</div>
							<div class="media">
								<a class="video-link" href="#">
								<div class="media-left">
									<img class="media-object" src="<?php echo base_url();?>assets/frontend/img/default2.jpg" alt="show">
								</div>
								<div class="media-body">
									<h4 class="media-heading">Happy New Year 2017, Wishes, video download,Whatsapp </h4>
									<div class="time-text">01:51</div>
								</div>
								</a>
							</div>
							<div class="media">
								<a class="video-link" href="#">
								<div class="media-left">
									<img class="media-object" src="<?php echo base_url();?>assets/frontend/img/default.jpg" alt="show">
								</div>
								<div class="media-body">
									<h4 class="media-heading">Happy New Year 2017, Wishes, video download,Whatsapp </h4>
									<div class="time-text">01:51</div>
								</div>
								</a>
							</div>
							<div class="media">
								<a class="video-link" href="#">
								<div class="media-left">
									<img class="media-object" src="<?php echo base_url();?>assets/frontend/img/default2.jpg" alt="show">
								</div>
								<div class="media-body">
									<h4 class="media-heading">Happy New Year 2017, Wishes, video download,Whatsapp </h4>
									<div class="time-text">01:51</div>
								</div>
								</a>
							</div>
							<div class="media">
								<a class="video-link" href="#">
								<div class="media-left">
									<img class="media-object" src="<?php echo base_url();?>assets/frontend/img/default2.jpg" alt="show">
								</div>
								<div class="media-body">
									<h4 class="media-heading">Happy New Year 2017, Wishes, video download,Whatsapp </h4>
									<div class="time-text">01:51</div>
								</div>
								</a>
							</div>
							<div class="media">
								<a class="video-link" href="#">
								<div class="media-left">
									<img class="media-object" src="<?php echo base_url();?>assets/frontend/img/default2.jpg" alt="show">
								</div>
								<div class="media-body">
									<h4 class="media-heading">Happy New Year 2017, Wishes, video download,Whatsapp </h4>
									<div class="time-text">01:51</div>
								</div>
								</a>
							</div>
							<div class="media">
								<a class="video-link" href="#">
								<div class="media-left">
									<img class="media-object" src="<?php echo base_url();?>assets/frontend/img/default.jpg" alt="show">
								</div>
								<div class="media-body">
									<h4 class="media-heading">Happy New Year 2017, Wishes, video download,Whatsapp </h4>
									<div class="time-text">01:51</div>
								</div>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!----youtube---end-->	
	
