
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>::Sums Real Estate::</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />

	<link href="<?php echo base_url();?>assets/frontend/owl-carousel/bootstrapTheme.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/frontend/owl-carousel/custom.css" rel="stylesheet">
    <!-- Owl Carousel Assets -->
    <link href="<?php echo base_url();?>assets/frontend/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/frontend/owl-carousel/owl.theme.css" rel="stylesheet">

	 <!-- Block Styles -->
	<link href="<?php echo base_url();?>assets/frontend/css/style.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>assets/frontend/css/gallery-1.css" rel="stylesheet">   

    <!-- Prettify -->
    <link href="<?php echo base_url();?>assets/frontend/owl-carousel/prettify.css" rel="stylesheet">

	<!-- Start WOWSlider.com HEAD section -->
	<link rel="stylesheet" type="text/css" href="<?php echo site_url();?>engine1/style.css" />
	<script type="text/javascript" src="<?php echo site_url();?>engine1/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section -->

    
 <!--coustom-css --> 
 <link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,600,700' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url();?>assets/frontend/materialize/css/materialize.min.css" media="screen,projection" />
<link href="<?php echo base_url();?>assets/frontend/css/bootstrap.min.css" rel="stylesheet" />
<link href="<?php echo base_url();?>assets/frontend/css/fancybox/jquery.fancybox.css" rel="stylesheet"> 
<link href="<?php echo base_url();?>assets/frontend/css/flexslider.css" rel="stylesheet" /> 
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/frontend/css/zoomslider.css" />
<link href="<?php echo base_url();?>assets/frontend/css/style.css" rel="stylesheet" /> 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->

	<link rel="shortcut icon" href="<?php echo base_url();?>assets/frontend/img/febicone.png">
</head>
<body>
<div id="wrapper" class="home-page"> 
	<header class="topbar">
		<div class="container">
			<div class="row">
				<!-- social icon-->
				<div class="col-sm-3">
				   <ul class="social-network">
					<li><a class="waves-effect waves-dark" href="https://web.facebook.com/sumsrealestate/"><i class="fa fa-facebook"></i></a></li>
					<li><a class="waves-effect waves-dark" href="#"><i class="fa fa-twitter"></i></a></li>
					<li><a class="waves-effect waves-dark" href="#"><i class="fa fa-linkedin"></i></a></li>
					<li><a class="waves-effect waves-dark" href="#"><i class="fa fa-pinterest"></i></a></li>
					<li><a class="waves-effect waves-dark" href="#"><i class="fa fa-google-plus"></i></a></li>
				</ul>
				</div>
				<div class="col-sm-9">
					<div class="row">
						<ul class="info"> 
							<li><i class="icon-info-blocks material-icons">question_answer</i><span>srcl2013@gmail.com</span></li>
							<li><i class="icon-info-blocks material-icons">perm_phone_msg</i><span>01718878797</span></li>
						</ul>
						<div class="clr"></div>
					</div>
				</div>
				<!-- info -->

			</div>
		</div>
	</header>
		
	<!-- start header -->
	<header>
		<div class="menu">
			<div class="navbar navbar-default navbar-static-top">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="<?php echo site_url();?>"><img src="<?php echo base_url();?>assets/frontend/img/logo.png" alt="show"></a>
					</div>
					<div class="navbar-collapse collapse ">
						<ul class="nav navbar-nav">
							<li class="HillSide"><a class="waves-effect waves-dark" href="<?php echo site_url();?>">Home</a></li> 
							 <li class="dropdown">
							<a href="#" data-toggle="dropdown" class="dropdown-toggle waves-effect waves-dark">About <b class="caret"></b></a>
							<ul class="dropdown-menu">
								<li><a class="waves-effect waves-dark" href="<?php echo site_url('site/about');?>">Company</a></li>
								<li><a class="waves-effect waves-dark" href="<?php echo site_url('site/our_team');?>">Our Team</a></li>
	
							</ul>
						</li> 
							<li><a class="waves-effect waves-dark" href="<?php echo site_url('site/projects');?>">Projects</a></li>
							<li><a class="waves-effect waves-dark" href="<?php echo site_url('site/gallery');?>">Gallery</a></li>
							<li><a class="waves-effect waves-dark" href="<?php echo site_url('site/contact');?>">Contact</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>	
	</header>
	<!-- end header -->