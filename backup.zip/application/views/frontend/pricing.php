
	<section id="inner-headline">
	<div class="container">
	
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Pricing</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
<section id="pricing">
        <div class="container">
           <div class="row"> 
							<div class="col-md-12">
								<div class="about-logo">
									<h3>Our Price<span class="color">List</span></h3>
									<p>Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas</p>
                                    	<p>Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas</p>
								</div>  
							</div>
						</div>
            <div class="row"> 
			<div class="col-md-4 menuItem">     
                                 <ul class="menu">
                                <li>
                                    Ddsaw
									 </li><li>
                                    <div class="detail">ipsum dolor sit amet, consectetur<span class="price">$14.49</span></div>
									 </li><li>
									 <div class="detail">ipsum dolor sit amet dskfj consectetur<span class="price">$20.50</span></div>
									 </li><li>
                                    <div class="detail">Semper aliquam quis mattis quam<span class="price">$9.99</span></div>
									</li><li>
                                    <div class="detail">ipsum dolor sit amet dskfj consectetur<span class="price">$17.99</span></div>
									</li><li>
                                    <div class="detail">ipsum dolor sit amet, consectetur<span class="price">$7.99</span></div>
									</li><li>
                                    <div class="detail">ipsum dolor sit amet, consectetur<span class="price">$14.49</span></div>
                                </li> 
								<li>
								<a href="#" class="btn btn-primary waves-effect waves-dark">Learn More</a></li>
								<li></li>
                            </ul>
                        </div>
						<div class="col-md-4 menuItem">     
                            <ul class="menu">
                                <li>
                                    Ddsaw
									 </li><li>
                                    <div class="detail">ipsum dolor sit amet, consectetur<span class="price">$14.49</span></div>
									 </li><li>
									 <div class="detail">ipsum dolor sit amet dskfj consectetur<span class="price">$20.50</span></div>
									 </li><li>
                                    <div class="detail">Semper aliquam quis mattis quam<span class="price">$9.99</span></div>
									</li><li>
                                    <div class="detail">ipsum dolor sit amet dskfj consectetur<span class="price">$17.99</span></div>
									</li><li>
                                    <div class="detail">ipsum dolor sit amet, consectetur<span class="price">$7.99</span></div>
									</li><li>
                                    <div class="detail">ipsum dolor sit amet, consectetur<span class="price">$14.49</span></div>
                                </li> 
								<li>
								<a href="#" class="btn btn-primary waves-effect waves-dark">Learn More</a></li>
								<li></li>
                            </ul>
                        </div>
						<div class="col-md-4 menuItem">  
                                 <ul class="menu">
                                <li>
                                    Ddsaw
									 </li><li>
                                    <div class="detail">ipsum dolor sit amet, consectetur<span class="price">$14.49</span></div>
									 </li><li>
									 <div class="detail">ipsum dolor sit amet dskfj consectetur<span class="price">$20.50</span></div>
									 </li><li>
                                    <div class="detail">Semper aliquam quis mattis quam<span class="price">$9.99</span></div>
									</li><li>
                                    <div class="detail">ipsum dolor sit amet dskfj consectetur<span class="price">$17.99</span></div>
									</li><li>
                                    <div class="detail">ipsum dolor sit amet, consectetur<span class="price">$7.99</span></div>
									</li><li>
                                    <div class="detail">ipsum dolor sit amet, consectetur<span class="price">$14.49</span></div>
                                </li> 
								<li>
								<a href="#" class="btn btn-primary waves-effect waves-dark">Learn More</a></li>
								<li></li>
                            </ul>
                        </div>
			</div>
        </div>
    </section>
	</section>
